#include "pch.h"
#include "WriterDecorator.h"